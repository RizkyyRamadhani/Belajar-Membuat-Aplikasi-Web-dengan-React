import React from 'react';
import NotesCard from './NotesCard';

function NotesActive({notes, onDelete, onActive}) {
    return (
        <div className='notes-list'>
                {
                    notes.map((note) => (
                        <NotesCard key={note.id} id={note.id} onDelete={onDelete} onActive={onActive} {...note}/>
                    ))
                }
        </div>

    )
}

export default NotesActive;